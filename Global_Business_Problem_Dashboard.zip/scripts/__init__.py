# scripts package init
